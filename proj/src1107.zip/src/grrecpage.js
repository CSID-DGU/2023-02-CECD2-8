import React from 'react';
import logo from './logo.png';
import { Link, useNavigate } from 'react-router-dom';
import './grrecpage.css';

function Grrecpage() {
  const navigate = useNavigate();
  return (
    <div className="grrecpage">
      <div className="sr-header">
        <Link to='/' className="sr-logo" style={{ textDecoration: "none" }} onClick={() => navigate('/mainpage')}>
          <img src={logo} className="sr-logoimg" alt="logo" />
        </Link>

        <div className='grr-title'>
            <span className='grr-title-text'> 연구 추천 </span>
        </div>
        
        <div class="sr-menu">
          <div class="sr-menu-icon">
            <div class="sr-bar"></div>
            <div class="sr-bar"></div>
            <div class="sr-bar"></div>
          </div>
          <Link to="/loginpage" className="sr-login" style={{ textDecoration: "none" }} onClick={() => navigate('/loginpage')}>
            <span className="sr-login-text">로그인</span>
          </Link>
        </div>
      </div>
      
      <div className="sr-line"></div>

      <div className="grr-contents">
        <div className='grr-content1'>
          <span>1. 연구분야키워드</span>
          <p>></p>
        </div>
        <div className='grr-content2'>
          <span>2. 연구분야키워드</span>
          <p>></p>
        </div>
        <div className='grr-content3'>
          <span>3. 연구분야키워드</span>
          <p>></p>
        </div>
        <div className='grr-content4'>
          <span>4. 연구분야키워드</span>
          <p>></p>
        </div>
        <div className='grr-content5'>
          <span>5. 연구분야키워드</span>
          <p>></p>
        </div>
      </div>


    </div>
  );
}

export default Grrecpage;
