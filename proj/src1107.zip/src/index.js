import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Mainpage from './mainpage';
import Loginpage from './loginpage';
import Signuppage from './signuppage';
import Srgsrecpage from './srgsrecpage';
import Srprofpage from './srprofpage';
import Srlabpage from './srlabpage';

import Serviceinfopage from './serviceinfopage';
import Gscndpage from './gscndpage';
import Cummunitypage from './cummunitypage';
import Univinfopage from './univinfopage';
import Profinfopage from './profinfopage';

import Gsrecpage from './gsrecpage';
import Grrecpage from './grrecpage';
import Gprecpage from './gprecpage';


import reportWebVitals from './reportWebVitals';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';


const root = ReactDOM.createRoot(document.getElementById('root'));
ReactDOM.render(
  <Router>
    <Routes>
      <Route path="/" element={<Mainpage />} />
      <Route path="/loginpage" element={<Loginpage />} />
      <Route path="/signuppage" element={<Signuppage />} />
      <Route path="/srgsrecpage" element={<Srgsrecpage />} />
      <Route path="/srprofpage" element={<Srprofpage />} />
      <Route path="/srlabpage" element={<Srlabpage />} />

      <Route path="/serviceinfopage" element={<Serviceinfopage />} />
      <Route path="/gscndpage" element={<Gscndpage />} />
      <Route path="/cummunitypage" element={<Cummunitypage />} />
      <Route path="/univinfopage" element={<Univinfopage />} />
      <Route path="/profinfopage" element={<Profinfopage />} />

      <Route path="/gsrecpage" element={<Gsrecpage />} />
      <Route path="/grrecpage" element={<Grrecpage />} />
      <Route path="/gprecpage" element={<Gprecpage />} />


    </Routes>
  </Router>,
  document.getElementById('root')
);

reportWebVitals();
