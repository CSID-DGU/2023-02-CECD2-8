<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $username = $_GET['username'];
    $password = $_GET['password'];
    $email = $_GET['email'];
    $name = $_GET['name'];
    $nickname = $_GET['nickname'];
    $birthdate = $_GET['birthdate'];
    $sex = $_GET['sex'];
    $nationality = $_GET['nationality'];

    
    $pdo = new PDO('mysql:host=localhost;dbname=cs', 'zhao', 'zhao7825169');
    $checkStmt = $pdo->prepare('SELECT COUNT(*) FROM user WHERE UserID = ?');
    $checkStmt->execute([$username]);
    $userCount = $checkStmt->fetchColumn();

    if ($userCount > 0) {
        
        echo json_encode(['message' => 'UserID already exists']);
    } else {
        
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        
        $insertStmt = $pdo->prepare('INSERT INTO user (UserID, Password, Email, Name, NickName, Year, Sex, Nationality) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $insertResult = $insertStmt->execute([$username, $hashedPassword, $email, $name, $nickname, $birthdate, $sex, $nationality]);

        if ($insertResult) {
            
            echo json_encode(['message' => 'Data received and user registered successfully']);
        } else {
            
            echo json_encode(['message' => 'Error registering user']);
        }
    }
} else {
   
    echo json_encode(['message' => 'Invalid request']);
}
?>
