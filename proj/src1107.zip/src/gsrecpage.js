import React from 'react';
import logo from './logo.png';
import { Link, useNavigate } from 'react-router-dom';
import './gsrecpage.css';

function Gsrecpage() {
  const navigate = useNavigate();
  return (
    <div className="gsrecpage">
      <div className="sr-header">
        <Link to='/' className="sr-logo" style={{ textDecoration: "none" }} onClick={() => navigate('/mainpage')}>
          <img src={logo} className="sr-logoimg" alt="logo" />
        </Link>

        <div className='gsr-title'>
            <span className='gsr-title-text'> 대학원 추천 </span>
        </div>
        
        <div class="sr-menu">
          <div class="sr-menu-icon">
            <div class="sr-bar"></div>
            <div class="sr-bar"></div>
            <div class="sr-bar"></div>
          </div>
          <Link to="/loginpage" className="sr-login" style={{ textDecoration: "none" }} onClick={() => navigate('/loginpage')}>
            <span className="sr-login-text">로그인</span>
          </Link>
        </div>
      </div>
      
      <div className="sr-line"></div>

      <div className="gsr-contents">
        <div className='gsr-content1'>
          <span>1. 대학명</span>
          <p>></p>
        </div>
        <div className='gsr-content2'>
          <span>2. 대학명</span>
          <p>></p>
        </div>
        <div className='gsr-content3'>
          <span>3. 대학명</span>
          <p>></p>
        </div>
        <div className='gsr-content4'>
          <span>4. 대학명</span>
          <p>></p>
        </div>
        <div className='gsr-content5'>
          <span>5. 대학명</span>
          <p>></p>
        </div>
      </div>
      
    </div>
  );
}

export default Gsrecpage;
