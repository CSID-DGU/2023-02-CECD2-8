<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

$servername = "localhost";
$username = "zhao";
$password = "zhao7825169";
$dbname = "cs";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("연결 실패: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = $_GET['query'];
    //$query = "Massachusetts Institute of Technology (MIT)";
    
    $professorSql = "SELECT * FROM professorinfo WHERE ProfessorName LIKE '%$query'";
    $professorResult = $conn->query($professorSql);
 
    if ($professorResult) {
        if ($professorResult->num_rows > 0) {
            $data = array();
            while ($professorRow = $professorResult->fetch_assoc()) {
                $universityId = $professorRow['UniversityID'];
   
               
                $UniversitySql = "SELECT * FROM universityinfo WHERE UniversityID = $universityId";
                $UniversityResult = $conn->query($UniversitySql);
                if ($UniversityResult) {
                    while ($UniversityRow = $UniversityResult->fetch_assoc()) {
                        $data[] = array_merge(array("UniversityName" => $UniversityRow["UniversityName"]),array("UniversitySite"=>$UniversityRow["UniversitySite"]), $professorRow);
                        
                    }
                }
                //$data[]= $professorRow;
            }
            echo json_encode($data);
           
        } else {
            echo json_encode(array("message" => "no Result"));
        }
    } else {
        echo json_encode(array("error" => "오류：" . $conn->error));
    }
    

    $conn->close();
}
?>
