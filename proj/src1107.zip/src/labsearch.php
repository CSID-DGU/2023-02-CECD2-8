<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

$servername = "localhost";
$username = "zhao";
$password = "zhao7825169";
$dbname = "cs";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("연결 실패: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = $_GET['query'];
    //$query = "Massachusetts Institute of Technology (MIT)";
    
    $labSql = "SELECT * FROM labinfo WHERE LabName LIKE '%$query'";
    $labResult = $conn->query($labSql);
 
    if ($labResult) {
        if ($labResult->num_rows > 0) {
            $data = array();
            while ($labRow = $labResult->fetch_assoc()) {
                $professorId = $labRow['ProfessorID'];
   
                
                $professorSql = "SELECT * FROM professorinfo WHERE professorID = $professorId";
                $professorResult = $conn->query($professorSql);
                if ($professorResult) {
                    while ($professorRow = $professorResult->fetch_assoc()) {
                        $data[] = array_merge(array("ProfessorName" => $professorRow["ProfessorName"]),array("SiteLink"=> $professorRow["SiteLink"]), $labRow);
                        //$data1[] = array_merge(array("SiteLink"=> $professorRow["SiteLink"]),$data);
                    }
                }
                //$data[]= $professorRow;
            }
           // echo json_encode($data);
            echo json_encode($data);
        } else {
            echo json_encode(array("message" => "no Result"));
        }
    } else {
        echo json_encode(array("error" => "오류：" . $conn->error));
    }
    

    $conn->close();
}
?>
