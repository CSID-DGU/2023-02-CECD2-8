<?php
header('Content-Type: application/json');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        
        $username = $_GET['username'];
        $password = $_GET['password'];

        
        $pdo = new PDO('mysql:host=localhost;dbname=cs', 'zhao', 'zhao7825169');

       
        $stmt = $pdo->prepare('SELECT Password FROM user WHERE UserID = ?');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['Password'])) {
           
            echo json_encode(['message' => 'Login successful']);
        } else {
            
            echo json_encode(['message' => 'Invalid username or password']);
        }
    } catch (Exception $e) {
        echo json_encode(['message' => 'An error occurred: ' . $e->getMessage()]);
    }
} else {
    
    echo json_encode(['message' => 'Invalid request']);
}

?>
