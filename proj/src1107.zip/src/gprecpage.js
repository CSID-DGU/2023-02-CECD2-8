import React from 'react';
import logo from './logo.png';
import { Link, useNavigate } from 'react-router-dom';
import './gprecpage.css';

function Gprecpage() {
  const navigate = useNavigate();
  return (
    <div className="gprecpage">
      <div className="sr-header">
        <Link to='/' className="sr-logo" style={{ textDecoration: "none" }} onClick={() => navigate('/mainpage')}>
          <img src={logo} className="sr-logoimg" alt="logo" />
        </Link>

        <div className='gpr-title'>
            <span className='gpr-title-text'> 교수 추천 </span>
        </div>
        
        <div class="sr-menu">
          <div class="sr-menu-icon">
            <div class="sr-bar"></div>
            <div class="sr-bar"></div>
            <div class="sr-bar"></div>
          </div>
          <Link to="/loginpage" className="sr-login" style={{ textDecoration: "none" }} onClick={() => navigate('/loginpage')}>
            <span className="sr-login-text">로그인</span>
          </Link>
        </div>
      </div>
      
      <div className="sr-line"></div>

      <div className="gpr-contents">
        <div className='gprr-content1'>
          <span>1. 교수명</span>
          <p>></p>
        </div>
        <div className='gprr-content2'>
          <span>2. 교수명</span>
          <p>></p>
        </div>
        <div className='gpr-content3'>
          <span>3. 교수명</span>
          <p>></p>
        </div>
        <div className='gpr-content4'>
          <span>4. 교수명</span>
          <p>></p>
        </div>
        <div className='gpr-content5'>
          <span>5. 교수명</span>
          <p>></p>
        </div>
      </div>

    </div>
  );
}

export default Gprecpage;
