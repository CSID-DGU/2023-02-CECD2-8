<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type: application/json, Authorization, X-Requested-With");


$host = 'localhost';
$username = 'zhao';
$password = 'zhao7825169';
$database = 'cs';

$conn = new mysqli($host, $username, $password, $database);


if ($conn->connect_error) {
    die("연결 실패：" . $conn->connect_error);
}

function executeQuery($conn, $tableIdentifier, $sql, $params, $a)
{
    $stmt = $conn->prepare($sql);
    $paramTypes = str_repeat('s', count($params)); 
    $stmt->bind_param($paramTypes, ...$params); 
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        if ($result->num_rows > 0) {
            $data = array();
            while ($row = $result->fetch_assoc()) {
                if (isset($row['UniversityLogo'])) {
                    $encodedLogo = base64_encode($row['UniversityLogo']);
                    $row['UniversityLogo'] = $encodedLogo;
                }
                
                
                $data[] = $row[$a];
            }
           
            $response = array(
                'tableIdentifier' => $tableIdentifier,
                'data' => $data,
            );
            echo json_encode($response);
            
        } else {
            echo json_encode(array("message" => "결과 없음"));
        }
    } else {
        echo json_encode(array("error" => "데이터베이스 쿼리 오류：" . $conn->error));
    }

    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
$selectedOption = $_GET['option'];
//$selectedOption = "location";
$searchQuery = $_GET['query'];
//$searchQuery="M";
$tableIdentifier = '';

if ($selectedOption == 'universityinfo' ) {
    
    $searchTerm = ['%' . $searchQuery . '%'];
    $tableIdentifier = 'universityinfo';
    $a = 'UniversityName';
    $sql = "SELECT * FROM `$selectedOption` WHERE $a LIKE ?";
    executeQuery($conn, $tableIdentifier, $sql, $searchTerm,$a);
}elseif($selectedOption == "location") {
    $searchTerm = ['%' . $searchQuery . '%'];
    $tableIdentifier = 'universityinfo';
    $a = 'UniversityName';
    $sql = "SELECT * FROM universityinfo WHERE State LIKE ?";
    executeQuery($conn, $tableIdentifier, $sql, $searchTerm,$a);
}elseif ($selectedOption == 'professorinfo') {
    
    $tableIdentifier = 'professorinfo';
    $a = 'ProfessorName';
    $searchTerm = ['%' . $searchQuery . '%'];
    $sql = "SELECT * FROM `$selectedOption` WHERE ProfessorName LIKE ?";
    executeQuery($conn, $tableIdentifier, $sql, $searchTerm,$a);
} elseif ($selectedOption == 'labinfo') {
    
    $tableIdentifier = 'labinfo';
    $a = 'LabName';
    $searchTerm = ['%' . $searchQuery . '%'];
    $sql = "SELECT * FROM `$selectedOption` WHERE LabName LIKE ?";
    executeQuery($conn, $tableIdentifier, $sql, $searchTerm,$a);
} else {
    echo json_encode(array("error" => "잘못된 쿼리 옵션"));
    exit;
}

$conn->close();
}
?>