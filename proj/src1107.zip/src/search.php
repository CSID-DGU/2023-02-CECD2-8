<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

$servername = "localhost";
$username = "zhao";
$password = "zhao7825169";
$dbname = "cs";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("연결 실패: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = $_GET['query'];
    //$query = "Massachusetts Institute of Technology (MIT)";
    
    $universitySql = "SELECT * FROM universityinfo WHERE UniversityName LIKE '%$query'";
    $universityResult = $conn->query($universitySql);

    if ($universityResult) {
        if ($universityResult->num_rows > 0) {
            $data = array();
            while ($universityRow = $universityResult->fetch_assoc()) {
                $universityId = $universityRow['UniversityID'];
    
                
                $majorSql = "SELECT * FROM majorinfo WHERE UniversityID = $universityId";
                $majorResult = $conn->query($majorSql);
                if (isset($universityRow['UniversityLogo'])) {
                    $encodedLogo = base64_encode($universityRow['UniversityLogo']);
                    $universityRow['UniversityLogo'] = $encodedLogo;
                }
                if ($majorResult) {
                    while ($majorRow = $majorResult->fetch_assoc()) {
                        $data[] =  $majorRow;
                    }
                } else {
                    $data[] = $universityRow;
                }
            }
            echo json_encode($data);
        } else {
            echo json_encode(array("message" => "no Result"));
        }
    } else {
        echo json_encode(array("error" => "오류：" . $conn->error));
    }
    

    $conn->close();
}
?>
